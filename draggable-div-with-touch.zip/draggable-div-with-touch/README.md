# Draggable Div with Touch

Make a div draggable with jQuery that stays within the Viewport and works on Touch devices.

More info: https://www.vanderwaal.eu/mini-projecten/draggable-div-with-touch

&nbsp;

<img src="https://www.vanderwaal.eu/files/draggable-div-with-touch.png">
